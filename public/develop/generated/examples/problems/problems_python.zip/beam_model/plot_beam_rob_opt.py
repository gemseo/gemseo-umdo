# Copyright 2021 IRT Saint Exupéry, https://www.irt-saintexupery.com
#
# This work is licensed under a BSD 0-Clause License.
#
# Permission to use, copy, modify, and/or distribute this software
# for any purpose with or without fee is hereby granted.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL
# WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL
# THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT,
# OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING
# FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
# NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
# WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
r"""# Robust optimization problem.

Minimize the expectation of the weight $w(h,t)$ w.r.t. the height $h\in[500, 800]$ and
the thickness $t\in[2,10]$ while satisfying $c_{\text{stress}}(h,t)\geq 1.0$ and
$c_{\text{displacement}}(h,t)\leq 1.0$ with probability 90\% where $F$, $E$ and
$\sigma_{\text{all}}$ are random variables defined by `BeamRandomSpace`.
"""

from __future__ import annotations

from gemseo.optimization import NLOPT_COBYLA_Settings
from gemseo.post import OptHistoryView_Settings

from gemseo_umdo.formulation.sampling_settings import Sampling_Settings
from gemseo_umdo.problem.beam_model.constraints import BeamConstraints
from gemseo_umdo.problem.beam_model.design_space import BeamDesignSpace
from gemseo_umdo.problem.beam_model.discipline import Beam
from gemseo_umdo.problem.beam_model.random_space import BeamRandomSpace
from gemseo_umdo.scenario.mdo import UMDOScenario

scenario = UMDOScenario(
    [Beam(), BeamConstraints()],
    BeamDesignSpace(),
    BeamRandomSpace(uniform=False),
    Sampling_Settings(n_samples=200),
)
scenario.add_objective("w", "Mean")
scenario.add_constraint(
    "c_stress", "Probability", greater=False, threshold=1.0, positive=True, value=0.9
)
scenario.add_constraint(
    "c_displ", "Probability", greater=True, threshold=1.0, positive=True, value=0.9
)
scenario.execute(NLOPT_COBYLA_Settings(max_iter=30))

scenario.post_process(OptHistoryView_Settings(save=False, show=True))
