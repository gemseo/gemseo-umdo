# Copyright 2021 IRT Saint Exupéry, https://www.irt-saintexupery.com
#
# This work is licensed under a BSD 0-Clause License.
#
# Permission to use, copy, modify, and/or distribute this software
# for any purpose with or without fee is hereby granted.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL
# WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL
# THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT,
# OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING
# FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
# NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
# WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
"""# The Sobieski's SSBJ MDO problem"""

from __future__ import annotations

from gemseo.optimization import NLOPT_COBYLA_Settings
from gemseo.post import OptHistoryView_Settings
from gemseo.problem.mdo.sobieski import SobieskiAerodynamics
from gemseo.problem.mdo.sobieski import SobieskiMission
from gemseo.problem.mdo.sobieski import SobieskiProblem
from gemseo.problem.mdo.sobieski import SobieskiPropulsion
from gemseo.problem.mdo.sobieski import SobieskiStructure
from gemseo.space import RandomSpace
from gemseo.uncertainty.distribution import OTNormalDistribution_Settings

from gemseo_umdo.formulations.taylor_polynomial_settings import (
    TaylorPolynomial_Settings,
)
from gemseo_umdo.scenarios.umdo_scenario import UMDOScenario

# %%
# Firstly,
# we instantiate the discipline of Sobieski's SSBJ problem:
mission = SobieskiMission()
structure = SobieskiStructure()
propulsion = SobieskiPropulsion()
aerodynamics = SobieskiAerodynamics()

# %%
# as well as the design space:
design_space = SobieskiProblem().design_space

# %%
# Secondly,
# we define the uncertain space:
uncertain_space = RandomSpace()
# %%
# with an uncertainty over the constant `"c_4"`:
uncertain_space.add_variable(
    "c_4", OTNormalDistribution_Settings(mu=0.01375, sigma=0.01375 * 0.05)
)
# %%
# and an uncertainty over the design variable `"x_2"`,
# expressed as an additive term `"u_x_2"`
# defined just after in the [UMDOScenario][gemseo_umdo.scenarios.umdo_scenario.UMDOScenario]:
uncertain_space.add_variable(
    "u_x_2", OTNormalDistribution_Settings(mu=0.0, sigma=1 * 0.05)
)

# %%
# Then,
# we build an [UMDOScenario][gemseo_umdo.scenarios.umdo_scenario.UMDOScenario]
# to maximize a first-order linearization-based estimation (default estimation method)
# of the expectation $\mathbb{E}[y_4]$:
scenario = UMDOScenario(
    [mission, structure, propulsion, aerodynamics],
    design_space,
    uncertain_space,
    TaylorPolynomial_Settings(),
    uncertain_design_variables={"x_2": ("+", "u_x_2")},
)
scenario.add_objective("y_4", "Mean", minimize=False)

# %%
# while satisfying margin constraints
# of the form $\mathbb{E}[g_i]+2\mathbb{S}[g_i]$
scenario.add_constraint("g_1", "Margin")
scenario.add_constraint("g_2", "Margin")
scenario.add_constraint("g_3", "Margin")

# %%
# and execute it with a gradient-free optimizer:
scenario.execute(NLOPT_COBYLA_Settings(max_iter=100))

# %%
# Lastly,
# we can plot the optimization history view:
scenario.post_process(OptHistoryView_Settings(save=False, show=True))
