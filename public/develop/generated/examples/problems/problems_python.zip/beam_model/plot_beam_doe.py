# Copyright 2021 IRT Saint Exupéry, https://www.irt-saintexupery.com
#
# This work is licensed under a BSD 0-Clause License.
#
# Permission to use, copy, modify, and/or distribute this software
# for any purpose with or without fee is hereby granted.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL
# WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL
# THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT,
# OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING
# FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
# NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
# WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
r"""# Large DOE study.

Sample the weight $w(h,t)$ and the constraints $c_{\text{stress}}(h,t)$ and
$c_{\text{displacement}}(h,t)$ w.r.t. the height $h\in[500, 800]$ and the thickness
$t\in[2,10]$.
"""

from __future__ import annotations

from gemseo.doe import PYDOE_FULLFACT_Settings
from gemseo.post.dataset import ZvsXY
from gemseo.post.dataset.zvsxy_settings import ZvsXY_Settings
from gemseo.scenario import MDOScenario

from gemseo_umdo.problem.beam_model.constraints import BeamConstraints
from gemseo_umdo.problem.beam_model.design_space import BeamDesignSpace
from gemseo_umdo.problem.beam_model.discipline import Beam

disciplines = [Beam(), BeamConstraints()]

design_space = BeamDesignSpace()

scenario = MDOScenario(disciplines, design_space)
scenario.add_objective("w")
scenario.add_constraint("c_stress", constraint_type="ineq", value=1.0)
scenario.add_constraint("c_displ", constraint_type="ineq", positive=True, value=1.0)
scenario.execute(PYDOE_FULLFACT_Settings(n_samples=10**2))

dataset = scenario.formulation.problem.to_dataset()
ZvsXY(dataset, settings=ZvsXY_Settings(x="h", y="t", z="w")).execute(
    save=True, show=False, file_name="w"
)
for constraint_name in ["-[c_displ-1.0]", "[c_stress-1.0]"]:
    for z_component in range(9):
        ZvsXY(
            dataset,
            settings=ZvsXY_Settings(x="h", y="t", z=(constraint_name, z_component)),
        ).execute(
            save=False,
            show=True,
        )
